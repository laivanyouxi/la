# Linux基础常用命令

## linux命令操作技巧：

1、你要知道你自己在哪一个路径下； pwd

2、你在这个路径下要干什么。

### pwd: 查看当前路径

### ls: 列出当前路径下的所有文件和文件夹

### ll: 列出文件或者文件夹的详细信息

### cd: 切换目录

### vi/touch: 创建文件，按A键或者i键进入编辑状态

### mkdir -p :创建文件夹

### tar -zxvf 包名：解压缩

### mv ：改名字或者移动文件

### cp:  备份

### find: 查找

## 软件安装：

### 1、rpm

### 2、yum

### 3、手动安装：解包然后配置

a.将压缩包上传

b.使用tar -zxvf 解压缩包

c.将解压过后的包的路径添加到/etc/profile（系统变量）当中

### JDK的环境变量配置：

```
export JAVA_HOME=/usr/java/jdk1.8.0_131
export JRE_HOME=${JAVA_HOME}/jre  
export CLASSPATH=.:${JAVA_HOME}/lib:${JRE_HOME}/lib  
export PATH=$PATH:${JAVA_HOME}/bin
```

